var barraProgresso = document.querySelector(".progress");
barraProgresso.style.display = "none";

function ValidarCadastro() {
    var idade = document.querySelector("#idade").value;
    var nome = document.querySelector("#nome").value;
    if (idade >= 0 || idade <= 190) {

    } 
    else {
        ExibirAlertaErro("Idade digitada é invalida");
        return
    }

    var progresso = 0;
    var barra = document.querySelector(".progress-bar");
    barraProgresso.style.display = "block";

    var intervalo = setInterval(function () {
        if (progresso > 100) {
            clearInterval(intervalo);
            barraProgresso.style.display = "none";
            document.querySelector("#mostrar").innerHTML = `<div class="alert alert-sucess fade show" role="alert">
                <span> ${nome} tem ${ idade } </span >
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button> </div>`
        } else{
            progresso++;
            barra.style.width = progresso + "%";
        }
    }, 50)

}
function ExibirAlertaErro(){
    document.querySelector("#mostrar").innerHTML = `<div class="alert alert-danger fade show" role="alert">
    <span> ${texto}</span>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>`;
}
